def kotak(x,y):
    for i in range(x):
        if i == 0 or i == x-1:
            print("@"*x)
        else :
            a = x- y
            print ("@"+" "*(x-2)+"@")
kotak(4,5)
